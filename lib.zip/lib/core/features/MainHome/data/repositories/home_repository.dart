class MainHomeRepository {
  const MainHomeRepository();
}
